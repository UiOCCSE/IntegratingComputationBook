This IPython notebook outline.ipynb does not require any additional
programs.
